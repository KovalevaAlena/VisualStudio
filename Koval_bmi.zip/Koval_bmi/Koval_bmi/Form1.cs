﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Koval_bmi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources._1;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources._2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float r =  Convert.ToInt32(textBox1.Text);
            float v = Convert.ToInt32(textBox2.Text);
            double r_m = Convert.ToInt32(r / 100);
            double ind = Math.Round((v / (r_m * r_m)), 1);
            label6.Text = ind.ToString();

            if (ind < 10)
            { trackBar1.Value = 10; label7.Text = "Недостаточный вес"; }
            else if (10 <= ind && ind < 18.5)
            { trackBar1.Value = Convert.ToInt32(ind); label7.Text = "Недостаточный вес"; }
            else if (18.5 <= ind && ind < 24.9)
            { trackBar1.Value = Convert.ToInt32(ind); label7.Text = "Здоровый вес"; }
            else if (24.9 <= ind && ind <= 30)
            { trackBar1.Value = Convert.ToInt32(ind); label7.Text = "Избыточный вес"; }
            else if (ind > 30 && ind < 40)
            { trackBar1.Value = Convert.ToInt32(ind); label7.Text = "Ожирение"; }
            else if (ind >= 40)
            { trackBar1.Value = 40; label7.Text = "Ожирение"; }
        }

        private void button_otmena_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            label7.ResetText();
            label6.ResetText();
            pictureBox3.Image = null;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            
        }
    }
}
